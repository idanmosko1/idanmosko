import React, { useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Upload, Image as ImageIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function UploadZone({ onFileUpload }) {
  const fileInputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    const imageFile = droppedFiles.find(file => file.type.startsWith("image/"));
    
    if (imageFile) {
      onFileUpload(imageFile);
    }
  };

  const handleFileInput = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith("image/")) {
      onFileUpload(file);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Card 
        className={`border-2 border-dashed transition-all duration-300 cursor-pointer hover:shadow-lg ${
          dragActive 
            ? "border-purple-400 bg-purple-50" 
            : "border-purple-200 bg-white/80 backdrop-blur-sm hover:border-purple-300"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={handleButtonClick}
      >
        <CardContent className="p-12 text-center">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileInput}
            className="hidden"
          />
          
          <motion.div
            animate={dragActive ? { scale: 1.1 } : { scale: 1 }}
            transition={{ duration: 0.2 }}
            className="mb-6"
          >
            <div className="w-20 h-20 mx-auto bg-gradient-to-r from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center mb-4">
              <ImageIcon className="w-10 h-10 text-purple-600" />
            </div>
          </motion.div>

          <h3 className="text-2xl font-bold text-gray-900 mb-3">
            העלה צילום מסך של השיחה
          </h3>
          <p className="text-gray-600 mb-8 text-lg">
            גרור את התמונה לכאן או לחץ לבחירת קובץ
          </p>

          <div className="grid md:grid-cols-2 gap-4 max-w-md mx-auto">
            <Button
              variant="outline"
              className="flex items-center justify-center gap-3 py-6 text-purple-600 border-purple-200 hover:bg-purple-50"
            >
              <Upload className="w-5 h-5" />
              בחר קובץ
            </Button>
            <Button
              variant="outline"
              className="flex items-center justify-center gap-3 py-6 text-pink-600 border-pink-200 hover:bg-pink-50"
            >
              <Camera className="w-5 h-5" />
              צלם עכשיו
            </Button>
          </div>

          <p className="text-sm text-gray-400 mt-6">
            תומך בקבצי PNG, JPG, JPEG
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}