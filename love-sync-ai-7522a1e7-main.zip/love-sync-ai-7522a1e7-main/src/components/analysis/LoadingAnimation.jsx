import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Brain, Eye, Zap, MessageCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const useSmoothProgress = (targetProgress) => {
  const [currentProgress, setCurrentProgress] = useState(0);
  const animationFrameId = useRef();

  useEffect(() => {
    const startProgress = currentProgress;
    let startTime = null;
    const duration = 800;

    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const elapsedTime = timestamp - startTime;
      const progressFraction = Math.min(elapsedTime / duration, 1);
      
      const easedFraction = 1 - Math.pow(1 - progressFraction, 2);
      const newProgress = startProgress + (targetProgress - startProgress) * easedFraction;
      
      setCurrentProgress(newProgress);

      if (elapsedTime < duration) {
        animationFrameId.current = requestAnimationFrame(animate);
      } else {
        setCurrentProgress(targetProgress);
      }
    };

    if (targetProgress > startProgress) {
        animationFrameId.current = requestAnimationFrame(animate);
    } else {
        setCurrentProgress(targetProgress);
    }

    return () => cancelAnimationFrame(animationFrameId.current);
  }, [targetProgress]);

  return Math.floor(currentProgress);
};

const PulsingBrain = () => (
  <motion.div
    className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl flex items-center justify-center"
    animate={{
      scale: [1, 1.05, 1],
      boxShadow: [
        "0 0 20px rgba(147, 51, 234, 0.3)",
        "0 0 40px rgba(147, 51, 234, 0.6)",
        "0 0 20px rgba(147, 51, 234, 0.3)"
      ]
    }}
    transition={{
      duration: 2,
      repeat: Infinity,
      ease: "easeInOut"
    }}
  >
    <Brain className="w-10 h-10 text-white" />
  </motion.div>
);

export default function LoadingAnimation({ progress, currentStep }) {
  const [motivationalText, setMotivationalText] = useState("");
  const animatedProgress = useSmoothProgress(progress);
  
  const motivationalTexts = [
    "בודק אם יש לך סיכוי...",
    "מנתח מה באמת בראש שלה/ו...", 
    "מכין לך את התגובה המנצחת...",
    "רגע, זה בעצם טוב...",
    "אוקיי יש כאן פוטנציאל..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMotivationalText(motivationalTexts[Math.floor(Math.random() * motivationalTexts.length)]);
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);

  const steps = [
    { icon: Eye, text: "קורא הכל", color: "text-blue-600" },
    { icon: Brain, text: "מבין את המשחק", color: "text-purple-600" },
    { icon: MessageCircle, text: "בודק רגשות", color: "text-pink-600" },
    { icon: Zap, text: "מכין תגובה", color: "text-yellow-600" }
  ];

  return (
    <Card className="border-2 border-purple-200 bg-white/95 backdrop-blur-sm shadow-2xl">
      <CardContent className="p-10">
        <div className="text-center mb-10">
          <PulsingBrain />
          
          <motion.h3 
            className="text-3xl font-bold text-gray-900 mb-3"
            animate={{ opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            מנתח את השיחה שלך...
          </motion.h3>
          
          <motion.p 
            className="text-gray-600 text-xl mb-2"
            key={currentStep}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {currentStep}
          </motion.p>
          
          <AnimatePresence mode="wait">
            <motion.p
              key={motivationalText}
              className="text-purple-600 text-lg font-medium"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5 }}
            >
              {motivationalText}
            </motion.p>
          </AnimatePresence>
        </div>

        <div className="space-y-8">
          <div className="relative">
            <Progress value={progress} className="h-4 bg-gray-100" />
            <motion.div
              className="absolute top-0 left-0 h-4 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 rounded-full"
              style={{ width: `${progress}%` }}
              animate={{
                boxShadow: [
                  "0 0 10px rgba(147, 51, 234, 0.5)",
                  "0 0 20px rgba(236, 72, 153, 0.7)",
                  "0 0 10px rgba(147, 51, 234, 0.5)"
                ]
              }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
            <div className="text-center mt-3">
              <motion.span 
                className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent"
              >
                {animatedProgress}%
              </motion.span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {steps.map((step, index) => {
              const isActive = progress > (index + 1) * 25;
              const isCurrentStep = progress > index * 25 && progress <= (index + 1) * 25;
              
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0.3, scale: 0.9 }}
                  animate={{ 
                    opacity: isActive || isCurrentStep ? 1 : 0.4,
                    scale: isActive || isCurrentStep ? 1 : 0.9,
                  }}
                  transition={{ duration: 0.5 }}
                  className="text-center"
                >
                  <div className={`w-16 h-16 mx-auto mb-3 rounded-2xl flex items-center justify-center ${
                    isActive || isCurrentStep ? 'bg-gradient-to-r from-purple-100 to-pink-100' : 'bg-gray-100'
                  }`}>
                    <step.icon className={`w-7 h-7 ${isActive || isCurrentStep ? step.color : 'text-gray-400'}`} />
                  </div>
                  <p className={`text-sm font-medium ${
                    isActive || isCurrentStep ? 'text-gray-900' : 'text-gray-400'
                  }`}>
                    {step.text}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}