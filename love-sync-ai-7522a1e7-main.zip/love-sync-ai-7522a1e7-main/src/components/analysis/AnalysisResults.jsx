
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Heart, 
  MessageCircle, 
  TrendingUp, 
  Brain, 
  Sparkles, 
  RotateCcw,
  Copy,
  Share,
  Lightbulb,
  Shuffle,
  Undo2,
  Clock // Added Clock icon
} from "lucide-react";
import { motion } from "framer-motion";
import { UserFeedback } from "@/api/entities"; // Added UserFeedback import

export default function AnalysisResults({ analysis, onNewAnalysis, onRegenerateReply, isRegenerating, replyHistory, onUndoRegenerate }) {
  const [userFeedback, setUserFeedback] = useState(null);
  const [showFeedbackOptions, setShowFeedbackOptions] = useState(true);

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600 bg-green-100";
    if (score >= 60) return "text-yellow-600 bg-yellow-100";
    if (score >= 40) return "text-orange-600 bg-orange-100";
    return "text-red-600 bg-red-100";
  };

  const getScoreEmoji = (score) => {
    if (score >= 80) return "🔥";
    if (score >= 60) return "😎";
    if (score >= 40) return "🤔";
    return "😅";
  };

  const getScoreText = (score) => {
    if (score >= 80) return "וואו, יש כאן משהו!";
    if (score >= 60) return "נראה טוב לגמרי!";
    if (score >= 40) return "יש פוטנציאל, בטח";
    return "צריך לעבוד על זה, בכיף";
  };

  const getEmotionalToneColor = (tone) => {
    const colors = {
      romantic: "bg-pink-100 text-pink-800",
      flirty: "bg-purple-100 text-purple-800",
      friendly: "bg-blue-100 text-blue-800",
      distant: "bg-gray-100 text-gray-800",
      confused: "bg-yellow-100 text-yellow-800",
      passionate: "bg-red-100 text-red-800",
      casual: "bg-green-100 text-green-800"
    };
    return colors[tone] || "bg-gray-100 text-gray-800";
  };

  const copyReply = () => {
    navigator.clipboard.writeText(analysis.suggested_reply);
  };

  const handleFeedback = async (reaction) => {
    try {
      await UserFeedback.create({
        analysis_id: analysis.id,
        user_reaction: reaction,
        original_reply: analysis.suggested_reply,
        context_tags: [analysis.emotional_tone, analysis.conversation_stage]
      });
      
      setUserFeedback(reaction);
      setShowFeedbackOptions(false);
      
      if (reaction === "thumbs_down") {
        // Auto-trigger regeneration
        setTimeout(() => {
          onRegenerateReply();
        }, 500);
      }
    } catch (error) {
      console.error("Failed to save feedback:", error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            טוב, בוא נראה מה קורה פה 👀
          </CardTitle>
          <p className="text-gray-600">
            כיף שאתה כאן!
          </p>
        </CardHeader>
      </Card>

      {/* Enhanced Interest Score */}
      <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-xl">
            <Heart className="w-6 h-6 text-pink-500" />
            איך אתם עומדים?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-6">
            <div className={`relative inline-flex items-center justify-center w-24 h-24 rounded-full text-3xl font-bold ${getScoreColor(analysis.mutual_interest_score)}`}>
              {analysis.mutual_interest_score}%
              <div className="absolute -top-2 -right-2 text-3xl transform rotate-12">
                {getScoreEmoji(analysis.mutual_interest_score)}
              </div>
            </div>
            <p className="text-lg font-semibold text-gray-700 mt-2">
              {getScoreText(analysis.mutual_interest_score)}
            </p>
          </div>
          
          {/* Interest Explanation */}
          {analysis.interest_explanation && (
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h4 className="font-semibold text-gray-800 mb-2">למה דווקא הציון הזה?</h4>
              <p className="text-gray-700">{analysis.interest_explanation}</p>
            </div>
          )}
          
          <Progress value={analysis.mutual_interest_score} className="h-4 mb-4" />
          
          {/* Warning Signals */}
          {analysis.warning_signals && analysis.warning_signals.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <h4 className="font-semibold text-red-800 mb-2">⚠️ נקודות שצריך לשים לב אליהן:</h4>
              <ul className="space-y-1">
                {analysis.warning_signals.map((signal, index) => (
                  <li key={index} className="text-red-700 text-sm">• {signal}</li>
                ))}
              </ul>
            </div>
          )}
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-sm">
            <div>
              <div className="font-semibold text-red-600">0-25%</div>
              <div className="text-gray-500">פחות מתחבר</div>
            </div>
            <div>
              <div className="font-semibold text-orange-600">26-50%</div>
              <div className="text-gray-500">יש סיכוי, בטח</div>
            </div>
            <div>
              <div className="font-semibold text-yellow-600">51-75%</div>
              <div className="text-gray-500">וואלה, זה טוב!</div>
            </div>
            <div>
              <div className="font-semibold text-green-600">76-100%</div>
              <div className="text-gray-500">בטחון! 🔥</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Analysis Insights */}
      <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-xl">
            <Brain className="w-6 h-6 text-purple-500" />
            מה הסיפור האמיתי?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex gap-2 flex-wrap">
            <Badge className={getEmotionalToneColor(analysis.emotional_tone)}>
              {analysis.emotional_tone}
            </Badge>
            <Badge variant="outline">
              {analysis.conversation_stage}
            </Badge>
            <Badge variant="outline">
              ביטחון: {analysis.confidence_level}
            </Badge>
          </div>
          <p className="text-gray-700 leading-relaxed text-lg">
            {analysis.analysis_insights}
          </p>
        </CardContent>
      </Card>

      {/* Interest Signals */}
      {analysis.interest_signals && analysis.interest_signals.length > 0 && (
        <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-xl">
              <TrendingUp className="w-6 h-6 text-green-500" />
              מה קלטתי כאן 👁️
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {analysis.interest_signals.map((signal, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200"
                >
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-800">{signal}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Enhanced Suggested Reply with Feedback */}
      <Card className="border-2 border-purple-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-xl">
            <MessageCircle className="w-6 h-6 text-blue-500" />
            {analysis.should_wait ? "הטיפ שלי אליך 💡" : "התשובה שתעיף את כולם 🚀"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <motion.div
            key={analysis.suggested_reply}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 mb-4 shadow-sm border"
          >
            <p className="text-xl text-gray-800 leading-relaxed font-medium">
              {analysis.suggested_reply}
            </p>
          </motion.div>
          
          {/* Timing Advice */}
          {analysis.timing_advice && (
            <div className="mb-4 p-4 bg-blue-100 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-5 h-5 text-blue-600" />
                <h4 className="font-semibold text-blue-800">עניין של טיימינג</h4>
              </div>
              <p className="text-sm text-blue-700">
                {analysis.timing_advice}
              </p>
            </div>
          )}
          
          {analysis.reply_psychology && (
            <motion.div
              key={analysis.reply_psychology}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mt-6 p-4 bg-indigo-100 rounded-lg border border-indigo-200"
            >
              <div className="flex items-center gap-2 mb-2">
                <Lightbulb className="w-5 h-5 text-indigo-600" />
                <h4 className="font-semibold text-indigo-800">למה זה עובד טוב</h4>
              </div>
              <p className="text-sm text-indigo-700">
                {analysis.reply_psychology}
              </p>
            </motion.div>
          )}

          {/* User Feedback Section */}
          {showFeedbackOptions && !userFeedback && (
            <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border">
              <h4 className="font-semibold text-gray-800 mb-3 text-center">איך ההצעה הזו בעיניך?</h4>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={() => handleFeedback("thumbs_up")}
                  className="bg-green-500 hover:bg-green-600 text-white flex items-center gap-2"
                >
                  👍 אהבתי בטירוף!
                </Button>
                <Button
                  onClick={() => handleFeedback("thumbs_down")}
                  variant="outline"
                  className="border-orange-300 text-orange-700 hover:bg-orange-50 flex items-center gap-2"
                >
                  👎 בוא ננסה משהו אחר
                </Button>
              </div>
            </div>
          )}

          {userFeedback === "thumbs_up" && (
            <div className="mt-4 p-3 bg-green-100 rounded-lg text-center">
              <p className="text-green-800 font-medium">🎉 וואו! בהצלחה עם זה!</p>
            </div>
          )}

          <div className="flex flex-wrap gap-3 mt-6">
             <Button
              onClick={onRegenerateReply}
              disabled={isRegenerating}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            >
              {isRegenerating ? (
                <>
                  <motion.div
                    className="mr-2"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <Shuffle className="w-4 h-4" />
                  </motion.div>
                  מייצר משהו חדש...
                </>
              ) : (
                <>
                  <Shuffle className="w-4 h-4 mr-2" />
                  תביא משהו אחר
                </>
              )}
            </Button>
            <Button 
              onClick={copyReply}
              variant="outline" 
              className="flex items-center gap-2"
            >
              <Copy className="w-4 h-4" />
              העתק
            </Button>
            {replyHistory && replyHistory.length > 0 && (
                <Button 
                  onClick={onUndoRegenerate}
                  variant="ghost" 
                  className="flex items-center gap-2 text-gray-500 hover:text-gray-800"
                >
                  <Undo2 className="w-4 h-4" />
                  חזור
                </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="flex justify-center">
            <Button
              onClick={onNewAnalysis}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-xl"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              יאללה, מנתחים עוד אחת!
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
