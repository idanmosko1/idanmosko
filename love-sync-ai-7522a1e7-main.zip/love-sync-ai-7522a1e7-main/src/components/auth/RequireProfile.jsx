import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User } from '@/api/entities';
import { UserProfile } from '@/api/entities';
import { createPageUrl } from '@/utils';

export default function RequireProfile({ children }) {
  const [profile, setProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkProfile = async () => {
      setIsLoading(true);
      try {
        const user = await User.me();
        const userProfile = await UserProfile.filter({ created_by: user.email }).then(results => results[0]);

        if (!userProfile || !userProfile.onboarding_completed) {
          navigate(createPageUrl("Landing"));
          return;
        }
        
        setProfile(userProfile);
      } catch (error) {
        console.error("User not authenticated or profile check failed, redirecting to Landing:", error);
        navigate(createPageUrl("Landing"));
      } finally {
        setIsLoading(false);
      }
    };

    checkProfile();
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">טוען פרופיל...</p>
        </div>
      </div>
    );
  }
  
  return profile ? children(profile) : null; 
}