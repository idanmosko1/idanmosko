import { base44 } from './base44Client';


export const Analysis = base44.entities.Analysis;

export const UserProfile = base44.entities.UserProfile;

export const GlobalLearning = base44.entities.GlobalLearning;

export const UserFeedback = base44.entities.UserFeedback;



// auth sdk:
export const User = base44.auth;