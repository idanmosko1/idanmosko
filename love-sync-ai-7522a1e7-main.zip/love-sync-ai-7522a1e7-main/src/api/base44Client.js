import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "6872d11e0f9887267522a1e7", 
  requiresAuth: true // Ensure authentication is required for all operations
});
