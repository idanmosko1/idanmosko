import React, { useState, useEffect } from "react";
import { Analysis } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BarChart3, Heart, Calendar, TrendingUp, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { he } from "date-fns/locale";
import { motion } from "framer-motion";
import RequireProfile from "../components/auth/RequireProfile";

function DashboardPageContent({ userProfile }) {
  const [analyses, setAnalyses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadAnalyses = async () => {
      if (userProfile) {
        try {
          setIsLoading(true);
          const userAnalyses = await Analysis.filter({ created_by: userProfile.created_by }, "-created_date");
          setAnalyses(userAnalyses);
        } catch (error) {
          console.error("Error loading analyses:", error);
        } finally {
          setIsLoading(false);
        }
      }
    };
    
    loadAnalyses();
  }, [userProfile]);

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    if (score >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const averageScore = analyses.length > 0 
    ? analyses.reduce((sum, analysis) => sum + analysis.mutual_interest_score, 0) / analyses.length 
    : 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
        <p className="text-gray-500 ml-3">טוען נתונים...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-start mb-8"
        >
          <div>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
              היסטוריית הניתוחים שלך
            </h1>
            <p className="text-lg text-gray-600">
              עקוב אחר כל הניתוחים והתקדמות שלך בעולם הדייטים
            </p>
          </div>
          <Link to={createPageUrl("Analysis")}>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
              <Plus className="w-5 h-5 mr-2" />
              ניתוח חדש
            </Button>
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">סך הניתוחים</CardTitle>
              <BarChart3 className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{analyses.length}</div>
              <p className="text-xs text-gray-500">
                {userProfile?.free_analyses_used || 0} מתוך {userProfile?.max_free_analyses || 5} ניתוחים חינמיים
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ציון עניין ממוצע</CardTitle>
              <Heart className="h-4 w-4 text-pink-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getScoreColor(averageScore)}`}>
                {averageScore.toFixed(0)}%
              </div>
              <p className="text-xs text-gray-500">
                על בסיס כל הניתוחים
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">טרנד השבוע</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">+12%</div>
              <p className="text-xs text-gray-500">
                שיפור בציוני העניין
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl font-bold">ניתוחים אחרונים</CardTitle>
          </CardHeader>
          <CardContent>
            {analyses.length === 0 ? (
              <div className="text-center py-12">
                <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-500 mb-2">
                  עדיין לא בוצעו ניתוחים
                </h3>
                <p className="text-gray-400 mb-6">
                  העלה את צילום המסך הראשון שלך כדי להתחיל
                </p>
                <Link to={createPageUrl("Analysis")}>
                  <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
                    התחל ניתוח ראשון
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {analyses.map((analysis, index) => (
                  <motion.div
                    key={analysis.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="border border-purple-100 rounded-xl p-6 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-gray-400" />
                        <span className="text-sm text-gray-500">
                          {format(new Date(analysis.created_date), "d MMMM yyyy, HH:mm", { locale: he })}
                        </span>
                      </div>
                      <div className={`text-2xl font-bold ${getScoreColor(analysis.mutual_interest_score)}`}>
                        {analysis.mutual_interest_score}%
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      <Badge className="bg-purple-100 text-purple-800">
                        {analysis.emotional_tone}
                      </Badge>
                      <Badge variant="outline">
                        {analysis.conversation_stage}
                      </Badge>
                      <Badge variant="outline">
                        ביטחון: {analysis.confidence_level}
                      </Badge>
                    </div>

                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-sm font-medium text-gray-600 mb-2">ההצעה לתגובה:</p>
                      <p className="text-gray-800 italic">
                        "{analysis.suggested_reply}"
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function DashboardPage() {
    return (
        <RequireProfile>
            {(profile) => <DashboardPageContent userProfile={profile} />}
        </RequireProfile>
    )
}