import React, { useState, useEffect } from "react";
import { UserProfile } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Heart, Sparkles, MessageCircle, ArrowLeft, ArrowRight, Sun, Moon, Clock } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function WelcomePage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [user, setUser] = useState(null);
  const [userName, setUserName] = useState("");
  const [greeting, setGreeting] = useState("");
  const [profileData, setProfileData] = useState({
    gender: "",
    relationship_stage: "",
    dating_goal: "",
    communication_style: "casual",
    display_name: ""
  });

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        
        // Set default name from user account
        const defaultName = currentUser.full_name?.split(' ')[0] || '';
        setUserName(defaultName);
        setProfileData(prev => ({ ...prev, display_name: defaultName }));
        
        // Set greeting based on time
        const now = new Date();
        const israelTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Jerusalem"}));
        const hour = israelTime.getHours();
        
        let timeGreeting = "";
        if (hour >= 5 && hour < 12) {
          timeGreeting = "בוקר טוב";
        } else if (hour >= 12 && hour < 17) {
          timeGreeting = "צהריים טובים";
        } else if (hour >= 17 && hour < 22) {
          timeGreeting = "ערב טוב";
        } else {
          timeGreeting = "לילה טוב";
        }
        
        setGreeting(timeGreeting);
        
        // Check if user already has a profile
        const existingProfile = await UserProfile.filter({ created_by: currentUser.email }).then(results => results[0]);
        if (existingProfile && existingProfile.onboarding_completed) {
          navigate(createPageUrl("Analysis"));
          return;
        }
      } catch (error) {
        console.error("User not authenticated, redirecting to Landing");
        navigate(createPageUrl("Landing"));
      }
    };
    
    checkAuth();
  }, [navigate]);

  const steps = [
    {
      title: `${greeting}, ${userName}! 👋`,
      subtitle: "איך תרצה שאקרא לך?",
      content: "name"
    },
    {
      title: "מה המגדר שלך? 🔥",
      subtitle: "כדי לתת לך את העצות הכי מדויקות",
      content: "gender"
    },
    {
      title: "מה המצב הרומנטי שלך? 💕",
      subtitle: "זה יעזור לנו להבין איך לגשת לשיחות",
      content: "relationship_stage"
    },
    {
      title: "מה אתה מחפש? 🎯",
      subtitle: "נכין עבורך תגובות שמתאימות למטרה שלך",
      content: "dating_goal"
    }
  ];

  const options = {
    gender: [
      { value: "male", label: "גבר", emoji: "👨", color: "from-blue-500 to-blue-600", desc: "קבל עצות איך לדבר עם נשים" },
      { value: "female", label: "אישה", emoji: "👩", color: "from-pink-500 to-pink-600", desc: "קבלי עצות איך לדבר עם גברים" }
    ],
    relationship_stage: [
      { value: "single", label: "רווק/ה", emoji: "🕺", color: "from-green-500 to-green-600" },
      { value: "dating", label: "בדייטים", emoji: "💃", color: "from-purple-500 to-purple-600" },
      { value: "relationship", label: "במערכת יחסים", emoji: "💑", color: "from-red-500 to-red-600" },
      { value: "complicated", label: "זה מסובך...", emoji: "🤷", color: "from-orange-500 to-orange-600" }
    ],
    dating_goal: [
      { value: "casual_dating", label: "דייטים רגילים", emoji: "☕", color: "from-yellow-500 to-yellow-600" },
      { value: "serious_relationship", label: "מערכת יחסים רצינית", emoji: "❤️", color: "from-red-500 to-red-600" },
      { value: "just_friends", label: "חברות", emoji: "🤝", color: "from-blue-500 to-blue-600" },
      { value: "hookup", label: "משהו קליל", emoji: "😉", color: "from-purple-500 to-purple-600" }
    ]
  };

  const updateProfile = (field, value) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const completeOnboarding = async () => {
    if (!user) return;

    try {
      const existingProfile = await UserProfile.filter({ created_by: user.email }).then(results => results[0]);
      
      const finalProfileData = {
        ...profileData,
        onboarding_completed: true,
        premium_status: false,
        analyses_count: 0,
        free_analyses_used: 0
      };

      if (existingProfile) {
        await UserProfile.update(existingProfile.id, finalProfileData);
      } else {
        await UserProfile.create(finalProfileData);
      }

      navigate(createPageUrl("Analysis"));
    } catch (error) {
      console.error("Error completing onboarding:", error);
    }
  };

  const isStepComplete = () => {
    if (currentStep === 0) return profileData.display_name.trim() !== "";
    const currentField = steps[currentStep]?.content;
    return currentField && profileData[currentField] !== "";
  };

  const getTimeIcon = () => {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 18) return <Sun className="w-5 h-5 text-yellow-500" />;
    return <Moon className="w-5 h-5 text-blue-400" />;
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">טוען...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 p-4 flex items-center justify-center">
      <div className="max-w-2xl mx-auto w-full">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            <div className="flex items-center gap-2">
              {getTimeIcon()}
              <span className="text-sm text-gray-500">שלב {currentStep + 1} מתוך {steps.length}</span>
            </div>
            <span className="text-sm text-gray-500">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <motion.div
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm shadow-xl">
              <CardHeader className="text-center pb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                  {steps[currentStep]?.title}
                </CardTitle>
                <p className="text-gray-600 text-lg">
                  {steps[currentStep]?.subtitle}
                </p>
              </CardHeader>
              
              <CardContent className="px-6 pb-8">
                {currentStep === 0 && (
                  <div className="space-y-4 mb-8">
                    <Label htmlFor="name" className="text-lg font-medium">איך תרצה שאקרא לך?</Label>
                    <Input
                      id="name"
                      value={profileData.display_name}
                      onChange={(e) => updateProfile("display_name", e.target.value)}
                      placeholder="השם שלך..."
                      className="text-lg p-4 text-center"
                      autoFocus
                    />
                    <p className="text-sm text-gray-500 text-center">
                      זה השם שאשתמש איתך בכל השיחות
                    </p>
                  </div>
                )}

                {steps[currentStep] && steps[currentStep].content !== "name" && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    {options[steps[currentStep].content]?.map((option) => (
                      <motion.button
                        key={option.value}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => updateProfile(steps[currentStep].content, option.value)}
                        className={`p-6 rounded-xl border-2 transition-all duration-300 ${
                          profileData[steps[currentStep].content] === option.value
                            ? `border-purple-400 bg-gradient-to-r ${option.color} text-white shadow-lg`
                            : "border-gray-200 hover:border-purple-300 bg-white"
                        }`}
                      >
                        <div className="text-center">
                          <div className="text-3xl mb-3">{option.emoji}</div>
                          <div className={`font-semibold text-lg ${
                            profileData[steps[currentStep].content] === option.value
                              ? "text-white"
                              : "text-gray-800"
                          }`}>
                            {option.label}
                          </div>
                          {option.desc && (
                            <p className={`text-sm mt-2 ${
                              profileData[steps[currentStep].content] === option.value
                                ? "text-white/90"
                                : "text-gray-500"
                            }`}>
                              {option.desc}
                            </p>
                          )}
                        </div>
                      </motion.button>
                    ))}
                  </div>
                )}

                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={prevStep}
                    disabled={currentStep === 0}
                    className="flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    חזור
                  </Button>
                  
                  <Button
                    onClick={nextStep}
                    disabled={!isStepComplete()}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white flex items-center gap-2 px-8"
                  >
                    {currentStep === steps.length - 1 ? (
                      <>
                        <Sparkles className="w-4 h-4" />
                        בוא נתחיל, {profileData.display_name}!
                      </>
                    ) : (
                      <>
                        המשך
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Footer */}
        <div className="text-center mt-8">
          <div className="flex items-center justify-center gap-2 text-gray-500 text-sm mb-2">
            <Clock className="w-4 h-4" />
            <span>זה לוקח רק דקה</span>
          </div>
          <p className="text-gray-500 text-sm">
            🔒 כל הנתונים שלך מוגנים ופרטיים לחלוטין
          </p>
        </div>
      </div>
    </div>
  );
}