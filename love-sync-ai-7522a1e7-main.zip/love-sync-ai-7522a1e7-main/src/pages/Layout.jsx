

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Heart, Camera, BarChart3, User, Crown, Sparkles, Menu, X, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";

const navigationItems = [
  {
    title: "ניתוח חדש",
    url: createPageUrl("Analysis"),
    icon: Camera,
    description: "העלה צילום מסך"
  },
  {
    title: "היסטוריית ניתוחים",
    url: createPageUrl("Dashboard"),
    icon: BarChart3,
    description: "כל הניתוחים שלך"
  },
  {
    title: "פרופיל אישי",
    url: createPageUrl("Profile"),
    icon: User,
    description: "הגדרות אישיות"
  }
];

export default function Layout({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setSidebarOpen(false);
        setSidebarCollapsed(false);
      } else {
        setSidebarOpen(true);
        if (location.pathname === createPageUrl("Analysis")) {
            setSidebarCollapsed(true);
        } else {
            setSidebarCollapsed(false);
        }
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [location.pathname]);

  const toggleSidebar = () => {
    if (window.innerWidth < 1024) {
      setSidebarOpen(!sidebarOpen);
    } else {
      setSidebarCollapsed(!sidebarCollapsed);
    }
  };
  
  const closeSidebar = () => {
    if (window.innerWidth < 1024) {
        setSidebarOpen(false);
    }
  }


  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <style>{`
        :root {
          --primary-purple: #7c3aed;
          --primary-pink: #ec4899;
          --accent-gold: #f59e0b;
          --text-primary: #1f2937;
          --text-secondary: #6b7280;
        }
      `}</style>

      <div className="min-h-screen flex">
        {/* Mobile Overlay */}
        <AnimatePresence>
          {sidebarOpen && window.innerWidth < 1024 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 z-40"
              onClick={closeSidebar}
            />
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <motion.div
          dir="rtl"
          initial={false}
          animate={{
            right: sidebarOpen ? 0 : "-100%",
            width: sidebarCollapsed ? "80px" : "320px"
          }}
          transition={{ type: "spring", damping: 30, stiffness: 300 }}
          className={`fixed lg:relative lg:right-0 top-0 h-full bg-white/90 backdrop-blur-sm border-l border-purple-100 z-50 shadow-xl lg:shadow-none overflow-hidden`}
        >
          {/* Sidebar Header */}
          <div className="border-b border-purple-100 p-6 flex items-center justify-between">
            {!sidebarCollapsed && (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    LoveSync AI
                  </h2>
                  <p className="text-sm text-gray-500">עוזר הדייטים החכם שלך</p>
                </div>
              </div>
            )}
            {sidebarCollapsed && (
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mx-auto">
                <Heart className="w-6 h-6 text-white" />
              </div>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSidebar}
              className="hidden lg:flex hover:bg-purple-50"
            >
              {sidebarCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={closeSidebar}
              className="lg:hidden"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Navigation */}
          <div className="p-4">
            <div className="mb-6">
              {!sidebarCollapsed && (
                <h3 className="text-sm font-medium text-gray-500 px-3 py-2 mb-2">
                  תפריט ראשי
                </h3>
              )}
              <div className="space-y-2">
                {navigationItems.map((item) => (
                  <Link
                    key={item.title}
                    to={item.url}
                    onClick={closeSidebar}
                    className={`flex items-center gap-4 rounded-xl p-4 transition-all duration-300 hover:bg-purple-50 hover:text-purple-700 ${
                      location.pathname === item.url
                        ? 'bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 shadow-sm'
                        : 'text-gray-600'
                    } ${sidebarCollapsed ? 'justify-center' : ''}`}
                    title={sidebarCollapsed ? item.title : ''}
                  >
                    <item.icon className="w-5 h-5" />
                    {!sidebarCollapsed && (
                      <div className="text-right">
                        <div className="font-medium">{item.title}</div>
                        <div className="text-xs opacity-70">{item.description}</div>
                      </div>
                    )}
                  </Link>
                ))}
              </div>
            </div>

            {/* Premium Section */}
            <div className={`${sidebarCollapsed ? "hidden" : "block"} mt-8`}>
              <Card className="bg-gradient-to-r from-purple-500 to-pink-500 border-0 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Crown className="w-5 h-5 text-yellow-300" />
                    <span className="font-semibold">Premium</span>
                  </div>
                  <p className="text-sm opacity-90 mb-3">
                    שדרג לגישה בלתי מוגבלת לניתוחים מתקדמים
                  </p>
                  <Link to={createPageUrl("Premium")} onClick={closeSidebar}>
                    <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-0">
                      שדרג עכשיו
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>

            {/* Collapsed Premium */}
            <div className={`${!sidebarCollapsed ? "hidden" : "flex"} mt-8 justify-center`}>
              <Link to={createPageUrl("Premium")} onClick={closeSidebar}>
                <Button size="icon" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white" title="שדרג ל-Premium">
                  <Crown className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Footer */}
          <div className="absolute bottom-0 left-0 right-0 border-t border-purple-100 p-4">
            <div className={`flex items-center gap-3 ${sidebarCollapsed ? 'justify-center' : ''}`}>
              <div className="w-10 h-10 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full flex items-center justify-center shrink-0">
                <User className="w-5 h-5 text-purple-600" />
              </div>
              <div className={`${sidebarCollapsed ? 'hidden' : 'block'} text-right overflow-hidden`}>
                <p className="font-medium text-gray-900 text-sm whitespace-nowrap">משתמש</p>
                <p className="text-xs text-gray-500 whitespace-nowrap">גרסה חינמית</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <main dir="rtl" className="flex-1 flex flex-col">
          {/* Header */}
          <header className="bg-white/80 backdrop-blur-sm border-b border-purple-100 px-6 py-4 flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSidebar}
              className="hover:bg-purple-50 transition-colors"
            >
              <Menu className="w-5 h-5 text-gray-600" />
            </Button>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <h1 className="text-lg font-semibold text-gray-900">LoveSync AI</h1>
            </div>
          </header>

          {/* Page Content */}
          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

