
import React, { useState, useEffect } from "react";
import { UserProfile } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User as UserIcon, Save, Crown, LogOut, Edit3 } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import RequireProfile from "../components/auth/RequireProfile";

function ProfilePageContent({ initialProfile }) {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(initialProfile);
  const [user, setUser] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (e) {
        console.error("Failed to fetch user", e);
      }
    };
    fetchUser();
  }, []);

  const handleLogout = async () => {
    await User.logout();
    navigate(createPageUrl("Landing"));
  };

  const saveProfile = async () => {
    if (!profile) return;
    setIsSaving(true);
    try {
      await UserProfile.update(profile.id, profile);
      setIsEditing(false);
    } catch (error) {
      console.error("Error saving profile:", error);
    } finally {
      setIsSaving(false);
    }
  };
  
  const cancelEditing = () => {
    setIsEditing(false);
    setProfile(initialProfile); 
  }

  const updateProfileField = (field, value) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
            הפרופיל האישי שלך
          </h1>
          <p className="text-lg text-gray-600">
            התאם את ההגדרות כדי לקבל ניתוחים והצעות מותאמות אישית
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
            <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm shadow-lg h-full flex flex-col">
              <CardHeader className="text-center">
                <div className="w-24 h-24 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full mx-auto mb-4 flex items-center justify-center border-4 border-white shadow-md">
                  <UserIcon className="w-12 h-12 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">{user?.full_name}</h3>
                <p className="text-sm text-gray-500">{user?.email}</p>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <span className="text-lg font-semibold">
                      {profile?.premium_status ? "Premium" : "חשבון חינמי"}
                    </span>
                    {profile?.premium_status && <Crown className="w-5 h-5 text-yellow-500" />}
                  </div>
                  <p className="text-sm text-gray-600">
                    {profile?.analyses_count || 0} ניתוחים סה"כ
                  </p>
                  <p className="text-sm text-gray-600">
                    {profile?.free_analyses_used || 0}/5 ניתוחים חינמיים החודש
                  </p>
                </div>
              </CardContent>
              <CardFooter className="p-4">
                <Button
                  variant="outline"
                  className="w-full flex items-center gap-2 text-red-600 hover:bg-red-50 hover:text-red-700"
                  onClick={handleLogout}
                >
                  <LogOut className="w-4 h-4" />
                  התנתק
                </Button>
              </CardFooter>
            </Card>
          </motion.div>

          <motion.div className="lg:col-span-2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-xl font-bold">ההעדפות שלי</CardTitle>
                {!isEditing && (
                  <Button variant="ghost" size="sm" onClick={() => setIsEditing(true)} className="flex items-center gap-2">
                    <Edit3 className="w-4 h-4" />
                    ערוך
                  </Button>
                )}
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-x-6 gap-y-8">
                  <div className="space-y-2">
                    <Label htmlFor="gender">אני</Label>
                    <Select
                      value={profile?.gender || "male"}
                      onValueChange={(value) => updateProfileField("gender", value)}
                      disabled={!isEditing}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">גבר</SelectItem>
                        <SelectItem value="female">אישה</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="dating_goal">מחפש/ת</Label>
                    <Select
                      value={profile?.dating_goal || "casual_dating"}
                      onValueChange={(value) => updateProfileField("dating_goal", value)}
                      disabled={!isEditing}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="casual_dating">דייטים קזואליים</SelectItem>
                        <SelectItem value="serious_relationship">מערכת יחסים רצינית</SelectItem>
                        <SelectItem value="just_friends">חברות בלבד</SelectItem>
                        <SelectItem value="hookup">קשר מזדמן</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="communication_style">סגנון התקשורת שלי</Label>
                    <Select
                      value={profile?.communication_style || "casual"}
                      onValueChange={(value) => updateProfileField("communication_style", value)}
                      disabled={!isEditing}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="confident">בטוח/ה בעצמי</SelectItem>
                        <SelectItem value="shy">ביישן/ית</SelectItem>
                        <SelectItem value="playful">שובב/ה</SelectItem>
                        <SelectItem value="serious">רציני/ת</SelectItem>
                        <SelectItem value="casual">רגיל/ה</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="preferred_reply_tone">טון מועדף לתגובות</Label>
                    <Select
                      value={profile?.preferred_reply_tone || "friendly"}
                      onValueChange={(value) => updateProfileField("preferred_reply_tone", value)}
                      disabled={!isEditing}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="direct">ישיר</SelectItem>
                        <SelectItem value="subtle">עדין</SelectItem>
                        <SelectItem value="humorous">הומוריסטי</SelectItem>
                        <SelectItem value="romantic">רומנטי</SelectItem>
                        <SelectItem value="friendly">ידידותי</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {isEditing && (
                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button variant="ghost" onClick={cancelEditing}>בטל</Button>
                    <Button
                      onClick={saveProfile}
                      disabled={isSaving}
                      className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                    >
                      {isSaving ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          שומר...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4 mr-2" />
                          שמור שינויים
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {!profile?.premium_status && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                <Card className="mt-8 border-2 border-yellow-200 bg-gradient-to-r from-yellow-50 to-amber-50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-yellow-800">
                      <Crown className="w-6 h-6" />
                      שדרג ל-Premium
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm list-disc list-inside mb-4 text-yellow-900">
                      <li>ניתוחים בלתי מוגבלים</li>
                      <li>ניתוחים מתקדמים יותר</li>
                      <li>הצעות תגובה מותאמות אישית</li>
                    </ul>
                    <Button className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-600 hover:to-amber-600 text-white">
                      שדרג עכשיו - ₪49/חודש
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default function ProfilePage() {
    return (
        <RequireProfile>
            {(profile) => <ProfilePageContent initialProfile={profile} />}
        </RequireProfile>
    )
}
