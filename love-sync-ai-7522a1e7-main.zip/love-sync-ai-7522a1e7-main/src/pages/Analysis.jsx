
import React, { useState } from "react";
import { Analysis, UserProfile, GlobalLearning } from "@/api/entities";
import { ExtractDataFromUploadedFile, UploadFile, InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, Brain, Sparkles } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

import RequireProfile from "../components/auth/RequireProfile";
import UploadZone from "../components/analysis/UploadZone";
import AnalysisResults from "../components/analysis/AnalysisResults";
import LoadingAnimation from "../components/analysis/LoadingAnimation";

function AnalysisPageContent({ userProfile }) {
  const [file, setFile] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState(null);
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState("");
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [replyHistory, setReplyHistory] = useState([]);

  const handleFileUpload = (uploadedFile) => {
    setFile(uploadedFile);
    setError(null);
    setAnalysisResult(null);
  };

  const analyzeUserStyle = async (conversationText) => {
    if (!userProfile || !conversationText) return null;

    try {
      const styleAnalysisPrompt = `
      נתח את הסגנון של המשתמש מהשיחה הזאת:
      """
      ${conversationText}
      """
      
      תחזיר מידע על:
      - אורך הודעות (קצר/בינוני/ארוך)
      - רמת הומור (0-10)
      - רמת ישירות (0-10) 
      - שימוש באימוג'ים
      - רמת ביטחון (0-10)
      - ביטויים אופייניים שהוא משתמש בהם
      - איך הוא בונה שיחות
      `;

      const styleAnalysis = await InvokeLLM({
        prompt: styleAnalysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            message_length_preference: { type: "string", enum: ["short", "medium", "long"] },
            humor_level: { type: "number" },
            directness_level: { type: "number" },
            emoji_usage: { type: "string", enum: ["none", "minimal", "moderate", "heavy"] },
            confidence_level: { type: "number" },
            typical_phrases: { type: "array", items: { type: "string" } },
            conversation_patterns: { type: "string" }
          }
        }
      });

      return styleAnalysis;
    } catch (error) {
      console.error("Style analysis failed:", error);
      return null;
    }
  };

  const updateUserLearning = async (userStyle, analysisResult) => {
    if (!userStyle || !userProfile) return;

    try {
      // Update user's learned style
      const updatedLearning = {
        ...(userProfile.learned_style || {}), // Ensure it's an object if undefined
        ...userStyle,
        typical_phrases: [
          ...(userProfile.learned_style?.typical_phrases || []),
          ...(userStyle.typical_phrases || [])
        ].slice(-20) // Keep only last 20 phrases
      };

      await UserProfile.update(userProfile.id, {
        learned_style: updatedLearning
      });

      // Add to global learning
      await GlobalLearning.create({
        pattern_type: "communication_pattern",
        pattern_data: {
          user_gender: userProfile.gender,
          style_data: userStyle,
          interaction_success: analysisResult.mutual_interest_score > 60 // Assuming score > 60 indicates success
        },
        effectiveness_score: Math.min(analysisResult.mutual_interest_score / 10, 10), // Scale 0-100 to 0-10
        age_group: "young_adults", // Placeholder, ideally this would come from userProfile
        gender_context: userProfile.gender
      });

    } catch (error) {
      console.error("Failed to update learning:", error);
    }
  };

  const getPersonalizedPrompt = async (conversationText, userStyle) => {
    // Get global learning patterns for this user type
    const globalPatterns = await GlobalLearning.filter({
      gender_context: userProfile.gender,
      pattern_type: "communication_pattern"
    }, "-effectiveness_score", 10); // Order by effectiveness_score descending, limit 10

    const learningContext = globalPatterns.length > 0 
      ? `מהדברים שלמדתי על ${userProfile.gender === "male" ? "גברים" : "נשים"} כמוך: ${JSON.stringify(globalPatterns.map(p => p.pattern_data))}`
      : "";

    const personalStyle = userStyle || userProfile.learned_style || {};
    
    // Ensure humor_level and directness_level are numbers for comparison, with defaults
    const humorLevel = typeof personalStyle.humor_level === 'number' ? personalStyle.humor_level : 5;
    const directnessLevel = typeof personalStyle.directness_level === 'number' ? personalStyle.directness_level : 5;

    if (userProfile.gender === "male") {
      return `
      אתה החבר הכי טוב שלי, בן 24, גאון בבנות. אתה לומד איך אני אוהב לקבל עצות.
      
      **מה שאתה יודע עלי:**
      - אני אוהב תשובות ${personalStyle.message_length_preference || "בינוני"}
      - רמת הומור שלי: ${humorLevel}/10
      - אני ${directnessLevel > 7 ? "ישיר" : directnessLevel < 4 ? "עדין" : "בינוני"}
      - ${personalStyle.typical_phrases?.length ? `אני בדרך כלל אומר דברים כמו: ${personalStyle.typical_phrases.slice(-3).join(", ")}` : ""}
      
      ${learningContext}
      
      **השיחה (Me: זה אני, Them: זאת היא):**
      """
      ${conversationText}
      """
      
      תן לי ניתוח בסגנון שלי בדיוק, כאילו אתה מכיר אותי שנים:
      - ציון עניין (0-100)
      - מה היא באמת חושבת
      - תגובה שמתאימה לסגנון שלי
      - למה זה יעבוד
      - טיפ אישי בשבילי
      `;
    } else {
      return `
      את החברה הכי טובה שלי, בת 23, גאון בבחורים. את לומדת איך אני אוהבת לקבל עצות.
      
      **מה שאת יודעת עלי:**
      - אני אוהבת תשובות ${personalStyle.message_length_preference || "בינוני"}
      - רמת הומור שלי: ${humorLevel}/10
      - אני ${directnessLevel > 7 ? "ישירה" : directnessLevel < 4 ? "עדינה" : "בינונית"}
      - ${personalStyle.typical_phrases?.length ? `אני בדרך כלל אומרת דברים כמו: ${personalStyle.typical_phrases.slice(-3).join(", ")}` : ""}
      
      ${learningContext}
      
      **השיחה (Me: זאת אני, Them: זה הוא):**
      """
      ${conversationText}
      """
      
      תני לי ניתוח בסגנון שלי בדיוק, כאילו את מכירה אותי שנים:
      - ציון עניין (0-100)
      - מה הוא באמת חושב
      - תגובה שמתאימה לסגנון שלי  
      - למה זה יעבוד
      - טיפ אישי בשבילי
      `;
    }
  };

  const analyzeScreenshot = async () => {
    if (!file || !userProfile) return;

    setIsAnalyzing(true);
    setError(null);
    setProgress(0);
    
    try {
      const originalName = file.name;
      const lastDot = originalName.lastIndexOf('.');
      const name = lastDot === -1 ? originalName : originalName.substring(0, lastDot);
      const ext = lastDot === -1 ? '' : originalName.substring(lastDot);
      const newName = name + ext.toLowerCase();

      const renamedFile = new File([file], newName, {
          type: file.type,
          lastModified: file.lastModified,
      });

      setCurrentStep("מעלה את הצילום...");
      setProgress(15);
      const { file_url } = await UploadFile({ file: renamedFile });

      setCurrentStep("מזהה אפליקציה וצבעי בועות...");
      setProgress(25);
      
      // First, identify the app and bubble colors
      const appIdentificationResult = await InvokeLLM({
        prompt: `
        נתח את צילום המסך הזה ותזהה:
        1. איזה אפליקציה זה (וואטסאפ, אינסטגרם, טלגרם, SMS)
        2. איזה צבע הבועות של המשתמש שהעלה את התמונה (בדרך כלל ירוק בוואטסאפ, כחול/סגול באינסטגרם)
        3. מיקום הבועות (ימין/שמאל)
        
        זה קריטי לזיהוי נכון של מי כתב מה.
        `,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            app_type: { type: "string", enum: ["whatsapp", "instagram", "telegram", "sms", "other"] },
            user_bubble_color: { type: "string", description: "צבע בועות המשתמש" },
            user_bubble_position: { type: "string", enum: ["right", "left"] },
            confidence: { type: "number", minimum: 0, maximum: 100 }
          },
          required: ["app_type", "user_bubble_color", "user_bubble_position"]
        }
      });

      const appInfo = appIdentificationResult;
      
      setCurrentStep("קורא את השיחה ומזהה דוברים...");
      setProgress(45);
      
      const extractionResult = await ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: "object",
          properties: {
            messages: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  speaker: { 
                    type: "string", 
                    enum: ["me", "them"],
                    description: `זהה מי שלח כל הודעה בהתבסס על מידע זה:
                    - אפליקציה: ${appInfo.app_type || 'לא ידוע'}
                    - צבע בועות המשתמש: ${appInfo.user_bubble_color || 'לא ידוע'}
                    - מיקום בועות המשתמש: ${appInfo.user_bubble_position || 'לא ידוע'}
                    'me' = המשתמש שהעלה את התמונה
                    'them' = הצד השני בשיחה`
                  },
                  text: { type: "string", description: "תוכן ההודעה המדויק" },
                  timestamp: { type: "string", description: "זמן השליחה אם קיים" }
                },
                required: ["speaker", "text"]
              }
            },
            last_message_by: {
              type: "string",
              enum: ["me", "them"],
              description: "מי שלח את ההודעה האחרונה בשיחה"
            },
            conversation_context: {
              type: "object",
              properties: {
                total_messages: { type: "number" },
                conversation_length: { type: "string", enum: ["short", "medium", "long"] },
                time_span: { type: "string", description: "כמה זמן התפרשה השיחה" },
                response_speed: { type: "string", enum: ["immediate", "quick", "slow", "very_slow"] }
              }
            }
          },
          required: ["messages", "last_message_by"]
        }
      });
      
      if (extractionResult.status !== "success" || !extractionResult.output || !extractionResult.output.messages || extractionResult.output.messages.length === 0) {
          throw new Error("לא הצלחתי לזהות את השיחה בתמונה. אנא נסה צילום מסך ברור יותר.");
      }

      const conversationData = extractionResult.output;
      const conversationText = conversationData.messages
        .map(msg => `${msg.speaker === 'me' ? 'Me' : 'Them'}: ${msg.text}`)
        .join('\n');
      
      setCurrentStep("מנתח את הדינמיקה ורמת העניין...");
      setProgress(70);
      
      const userName = userProfile.display_name || "חבר";
      const isUserLastMessage = conversationData.last_message_by === "me";
      
      let analysisPrompt = "";
      
      if (userProfile.gender === "male") {
        analysisPrompt = `
        אתה החבר הכי טוב של ${userName}, בן 24, מלך של דייטים ופסיכולוגיה של בחורות.
        ${userName} שלח לך שיחה עם בחורה והוא צריך עזרה.

        **השיחה:**
        """
        ${conversationText}
        """

        **הקשר:**
        - סה"כ הודעות: ${conversationData.conversation_context?.total_messages || 'לא ידוע'}
        - אורך השיחה: ${conversationData.conversation_context?.conversation_length || 'לא ידוע'}
        - מהירות תגובה: ${conversationData.conversation_context?.response_speed || 'לא ידוע'}
        
        **מי כתב אחרון:** ${isUserLastMessage ? `${userName} כתב אחרון` : 'הבחורה כתבה אחרון'}

        **תן ל${userName} עצה כמו חבר אמיתי בשפת רחוב צעירה:**
        
        תקרא את כל השיחה בשביל להבין את הוויב, אבל התגובה שלך תהיה על ההודעה האחרונה.
        
        ${isUserLastMessage ? 
           `${userName} כתב אחרון - תגיד לו אם לחכות, לשלוח עוד או לעזוב. תהיה כנה!` :
           `הבחורה כתבה אחרון - תן ל${userName} תגובה מנצחת שמתאימה בדיוק להודעה שלה`}

        תן לו:
        - ציון עניין מדויק עם הסבר ברור (למה הציון הזה)
        - מה היא באמת חושבת (תהיה כנה)
        - מה לעשות עכשיו (תגובה ספציפית או עצה לחכות/לעזוב) - בלי גירשיים, פשוט התגובה
        - למה זה יעבוד (פסיכולוגיה)
        - טיפ זהב לרגע הזה

        דבר אליו כמו חבר צעיר, בשפת רחוב, בלי מילים חנוניות כמו "לשלב" או "להתמקד".
        `;
      } else {
        analysisPrompt = `
        את החברה הכי טובה של ${userName}, בת 23, גאון בבחורים.
        ${userName} שלחה לך שיחה עם בחור והיא צריכה עזרה.

        **השיחה:**
        """
        ${conversationText}
        """

        **הקשר:**
        - סה"כ הודעות: ${conversationData.conversation_context?.total_messages || 'לא ידוע'}
        - אורך השיחה: ${conversationData.conversation_context?.conversation_length || 'לא ידוע'}
        - מהירות תגובה: ${conversationData.conversation_context?.response_speed || 'לא ידוע'}
        
        **מי כתב אחרון:** ${isUserLastMessage ? `${userName} כתבה אחרון` : 'הבחור כתב אחרון'}

        **תני ל${userName} עצה כמו חברה אמיתית בשפת רחוב צעירה:**
        
        תקראי את כל השיחה בשביל להבין את הוויב, אבל התגובה שלך תהיה על ההודעה האחרונה.
        
        ${isUserLastMessage ? 
           `${userName} כתבה אחרון - תגידי לה אם לחכות, לשלוח עוד או לעזוב. תהיי כנה!` :
           `הבחור כתב אחרון - תני ל${userName} תגובה חכמה שמתאימה בדיוק להודעה שלו`}

        תני לה:
        - ציון עניין מדויק עם הסבר ברור (למה הציון הזה)
        - מה הוא באמת חושב (תהיי כנה)
        - מה לעשות עכשיו (תגובה ספציפית או עצה לחכות/לעזוב) - בלי גירשיים, פשוט התגובה
        - למה זה יעבוד (פסיכולוגיה)
        - טיפ זהב לרגע הזה

        דברי אליה כמו חברה צעירה, בשפת רחוב, בלי מילים חנוניות כמו "לשלב" או "להתמקד".
        `;
      }

      const aiAnalysis = await InvokeLLM({
        prompt: analysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            mutual_interest_score: { type: "number", minimum: 0, maximum: 100 },
            interest_explanation: { type: "string", description: "הסבר מפורט למה הציון הזה" },
            analysis_insights: { type: "string", description: "מה באמת קורה בשיחה" },
            suggested_reply: { type: "string", description: "התגובה המוצעת או העצה מה לעשות" },
            reply_psychology: { type: "string", description: "למה זה יעבוד - פסיכולוגיה" },
            interest_signals: { type: "array", items: { type: "string" }, description: "אותות עניין שזוהו" },
            warning_signals: { type: "array", items: { type: "string" }, description: "אותות אזהרה אם יש" },
            emotional_tone: { type: "string", enum: ["romantic", "flirty", "friendly", "distant", "confused", "passionate", "casual"] },
            conversation_stage: { type: "string", enum: ["initial_contact", "getting_to_know", "flirting", "romantic_tension", "relationship_building"] },
            confidence_level: { type: "string", enum: ["low", "medium", "high"] },
            should_wait: { type: "boolean", description: "האם עדיף לחכות במקום להגיב" },
            timing_advice: { type: "string", description: "עצות לגבי טיימינג - מתי להגיב" }
          },
          required: ["mutual_interest_score", "interest_explanation", "analysis_insights", "suggested_reply", "reply_psychology"]
        }
      });

      setCurrentStep("מסיים ניתוח...");
      setProgress(90);

      const analysisData = {
        screenshot_url: file_url,
        conversation_text: conversationText,
        last_message_by: conversationData.last_message_by,
        app_context: appInfo,
        conversation_context: conversationData.conversation_context,
        ...aiAnalysis
      };

      const savedAnalysis = await Analysis.create(analysisData);
      
      await UserProfile.update(userProfile.id, {
        analyses_count: (userProfile.analyses_count || 0) + 1,
        free_analyses_used: (userProfile.free_analyses_used || 0) + 1
      });

      setProgress(100);
      setCurrentStep("הניתוח הושלם!");
      setAnalysisResult(savedAnalysis);
      setReplyHistory([]); // Reset history for new analysis

    } catch (error) {
      console.error("Analysis error:", error);
      if (error.message.startsWith("לא הצלחתי לזהות")) {
          setError(error.message);
      } else {
          setError("משהו השתבש, נסה שוב");
      }
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  const regenerateReply = async () => {
    if (!analysisResult) return;
    
    setIsRegenerating(true);
    try {
        setReplyHistory(prev => [...prev, { 
            suggested_reply: analysisResult.suggested_reply,
            reply_psychology: analysisResult.reply_psychology 
        }]);

        const tones = ["שנון יותר", "מצחיק יותר", "מסתורי יותר", "ישיר ונועז", "אדיש וקליל", "זורם עם הומור"];
        const randomTone = tones[Math.floor(Math.random() * tones.length)];

        const targetGender = userProfile.gender === "male" ? "בחורה" : "בחור";
        const userGender = userProfile.gender === "male" ? "גבר" : "אישה";
        
        const regenerationPrompt = `
        יש לי שיחה עם ${targetGender} ואני ${userGender}. 
        תן לי הצעת תגובה אחרת בסגנון ${randomTone}.
        שפת רחוב, בלי ניקוד, קצר וקולע.

        השיחה:
        """
        ${analysisResult.conversation_text}
        """

        תחזיר רק התגובה והסבר קצר.
        אל תכתוב "Me:" או גירשיים - פשוט את התגובה.
        `;

        const newReplyData = await InvokeLLM({
            prompt: regenerationPrompt,
            response_json_schema: {
                type: "object",
                properties: {
                    suggested_reply: { type: "string" },
                    reply_psychology: { type: "string" }
                },
                required: ["suggested_reply", "reply_psychology"]
            }
        });

        const updatedAnalysis = {
            ...analysisResult,
            suggested_reply: newReplyData.suggested_reply,
            reply_psychology: newReplyData.reply_psychology
        };

        setAnalysisResult(updatedAnalysis);
        // Persist the regenerated reply
        await Analysis.update(analysisResult.id, {
            suggested_reply: newReplyData.suggested_reply,
            reply_psychology: newReplyData.reply_psychology
        });

    } catch (error) {
        console.error("Failed to regenerate reply", error);
        // Optionally, set an error state to show the user
    } finally {
        setIsRegenerating(false);
    }
  };

  const handleUndoRegenerate = () => {
    if (replyHistory.length === 0) return;
    
    const lastReply = replyHistory[replyHistory.length - 1];
    
    setAnalysisResult(prev => ({
        ...prev,
        suggested_reply: lastReply.suggested_reply,
        reply_psychology: lastReply.reply_psychology
    }));
    
    setReplyHistory(prev => prev.slice(0, -1));
  };


  const resetAnalysis = () => {
    setFile(null);
    setAnalysisResult(null);
    setError(null);
    setProgress(0);
    setCurrentStep("");
    setReplyHistory([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center">
              <Brain className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-3">
            ניתוח שיחה חכם
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            העלה צילום מסך של השיחה שלך וקבל ניתוח מקצועי עם הצעות לתגובה מותאמות במיוחד עבורך
          </p>
          {userProfile && (
            <div className="mt-4 flex justify-center">
              <Badge className="bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800">
                {userProfile.gender === "male" ? "יועץ לגברים" : "יועצת לנשים"} • {userProfile.dating_goal?.replace(/_/g, ' ')}
              </Badge>
            </div>
          )}
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Conditional rendering without AnimatePresence for simplicity */}
        {!analysisResult && !isAnalyzing && (
            <div>
              <UploadZone onFileUpload={handleFileUpload} />
              
              {file && (
                <div className="mt-6">
                  <Card className="border-2 border-purple-200 bg-white/80 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                            <Camera className="w-6 h-6 text-purple-600" />
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{file.name}</p>
                            <p className="text-sm text-gray-500">
                              {(file.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </div>
                        </div>
                        <Button
                          onClick={analyzeScreenshot}
                          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-xl"
                        >
                          <Sparkles className="w-5 h-5 mr-2" />
                          נתח שיחה
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          )}

          {isAnalyzing && (
            <div>
              <LoadingAnimation 
                progress={progress}
                currentStep={currentStep}
              />
            </div>
          )}

          {analysisResult && (
            <div>
              <AnalysisResults 
                analysis={analysisResult}
                onNewAnalysis={resetAnalysis}
                onRegenerateReply={regenerateReply}
                isRegenerating={isRegenerating}
                replyHistory={replyHistory}
                onUndoRegenerate={handleUndoRegenerate}
              />
            </div>
          )}
      </div>
    </div>
  );
}

export default function AnalysisPage() {
    return (
        <RequireProfile>
            {(profile) => <AnalysisPageContent userProfile={profile} />}
        </RequireProfile>
    )
}
