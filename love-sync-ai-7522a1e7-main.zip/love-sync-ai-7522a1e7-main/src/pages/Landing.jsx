import React, { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Sparkles, Users, LogIn } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";

export default function LandingPage() {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already authenticated
    const checkAuth = async () => {
      try {
        const user = await User.me();
        // If authenticated, go to gender selection
        navigate(createPageUrl("Welcome"));
      } catch (error) {
        // Not authenticated, stay on landing page
      }
    };
    
    checkAuth();
  }, [navigate]);

  const handleLogin = async () => {
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl("Welcome"));
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 p-4 flex items-center justify-center">
      <div className="max-w-2xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl mx-auto mb-6 flex items-center justify-center">
            <Heart className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            LoveSync AI
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            העוזר החכם שלך לדייטים ושיחות
          </p>
          <div className="flex items-center justify-center gap-2 text-gray-500">
            <Users className="w-5 h-5" />
            <span>אלפי משתמשים כבר מקבלים עצות מנצחות</span>
          </div>
        </motion.div>

        <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm shadow-xl">
          <CardHeader className="text-center pb-6">
            <CardTitle className="text-2xl font-bold text-gray-900 mb-2">
              בוא נתחיל להעלות לך את הרמה בדייטים! 🚀
            </CardTitle>
            <p className="text-gray-600">
              הכניסה מהירה ובטוחה עם Google
            </p>
          </CardHeader>
          
          <CardContent className="px-8 pb-8">
            <div className="text-center">
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  onClick={handleLogin}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-6 text-lg rounded-xl"
                >
                  <LogIn className="w-6 h-6 mr-3" />
                  התחבר עם Google
                </Button>
              </motion.div>
              
              <p className="text-sm text-gray-500 mt-4">
                מהיר, בטוח ובלי ספאם
              </p>
            </div>

            <div className="mt-8 text-center">
              <div className="flex items-center justify-center gap-6 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-500" />
                  <span>ניתוחים מותאמים אישית</span>
                </div>
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-pink-500" />
                  <span>עצות מנצחות</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-8">
          <p className="text-gray-500 text-sm">
            🔒 כל הנתונים שלך מוגנים ופרטיים לחלוטין
          </p>
        </div>
      </div>
    </div>
  );
}