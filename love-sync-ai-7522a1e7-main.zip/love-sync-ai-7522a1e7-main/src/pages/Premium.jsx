import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Check, Sparkles, Heart, Brain, MessageCircle, BarChart3, Shield } from "lucide-react";
import { motion } from "framer-motion";

export default function PremiumPage() {
  const features = [
    {
      icon: Brain,
      title: "ניתוחים בלתי מוגבלים",
      description: "נתח כמה שיחות שאתה רוצה ללא הגבלה",
      free: "5 בחינם",
      premium: "ללא הגבלה"
    },
    {
      icon: Sparkles,
      title: "ניתוחים מתקדמים",
      description: "קבל תובנות עמוקות יותר ויותר מדויקות",
      free: "בסיסי",
      premium: "מתקדם"
    },
    {
      icon: MessageCircle,
      title: "הצעות תגובה מותאמות",
      description: "תגובות שמותאמות לסגנון שלך ולמטרה שלך",
      free: "סטנדרטי",
      premium: "אישי"
    },
    {
      icon: BarChart3,
      title: "סטטיסטיקות מפורטות",
      description: "עקוב אחר ההתקדמות שלך עם דוחות מפורטים",
      free: "בסיסי",
      premium: "מלא"
    },
    {
      icon: Heart,
      title: "אלגוריתם למידה",
      description: "המערכת לומדת את הסגנון שלך ומשתפרת עם הזמן",
      free: "❌",
      premium: "✅"
    },
    {
      icon: Shield,
      title: "תמיכה עדיפות",
      description: "קבל תמיכה מהירה ומקצועית בכל עת",
      free: "❌",
      premium: "✅"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-3xl flex items-center justify-center">
              <Crown className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent mb-4">
            שדרג ל-Premium
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            פתח את כל הכוח של LoveSync AI וקבל ניתוחים מתקדמים, הצעות תגובה מותאמות אישית ותמיכה מלאה
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {/* Free Plan */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="border-2 border-gray-200 bg-white/90 backdrop-blur-sm">
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-2xl font-bold text-gray-900">תוכנית חינמית</CardTitle>
                <div className="text-4xl font-bold text-gray-600 mt-4">₪0</div>
                <p className="text-gray-500">לחודש</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>5 ניתוחים בחינם בחודש</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>ניתוח בסיסי של השיחות</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>הצעות תגובה סטנדרטיות</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>היסטוריית ניתוחים</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full mt-8" disabled>
                  התוכנית הנוכחית שלך
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Premium Plan */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="border-2 border-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50 relative overflow-hidden">
              <div className="absolute top-4 right-4">
                <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                  הכי פופולרי
                </Badge>
              </div>
              <CardHeader className="text-center pb-8 pt-8">
                <CardTitle className="text-2xl font-bold text-gray-900 flex items-center justify-center gap-2">
                  <Crown className="w-6 h-6 text-yellow-600" />
                  תוכנית Premium
                </CardTitle>
                <div className="text-4xl font-bold text-yellow-600 mt-4">₪49</div>
                <p className="text-gray-600">לחודש</p>
                <p className="text-sm text-green-600 font-medium">חסוך 30% עם חיוב שנתי</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="font-medium">ניתוחים ללא הגבלה</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="font-medium">ניתוח AI מתקדם</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="font-medium">הצעות תגובה מותאמות אישית</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="font-medium">סטטיסטיקות מפורטות</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="font-medium">אלגוריתם למידה אישי</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="font-medium">תמיכה עדיפות 24/7</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="font-medium">גישה לפיצ'רים חדשים קודם</span>
                  </li>
                </ul>
                <Button className="w-full mt-8 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white text-lg py-6">
                  <Crown className="w-5 h-5 mr-2" />
                  שדרג עכשיו
                </Button>
                <p className="text-center text-sm text-gray-500 mt-4">
                  ניתן לבטל בכל עת • ללא התחייבות
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Feature Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-center">השוואת תכונות</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className="grid md:grid-cols-2 gap-6 items-center p-4 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-100 to-pink-100 rounded-xl flex items-center justify-center">
                        <feature.icon className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">{feature.title}</h3>
                        <p className="text-sm text-gray-600">{feature.description}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-sm font-medium text-gray-500 mb-1">חינמי</p>
                        <Badge variant="outline" className="text-gray-600">
                          {feature.free}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-500 mb-1">Premium</p>
                        <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                          {feature.premium}
                        </Badge>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="text-center mt-16"
        >
          <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                מוכן להעלות את משחק הדייטים שלך?
              </h2>
              <p className="text-gray-600 mb-6 text-lg">
                הצטרף לאלפי משתמשים שכבר משפרים את כישורי התקשורת שלהם עם LoveSync AI
              </p>
              <Button 
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-12 py-4 text-lg"
              >
                התחל הניסיון החינמי של 7 ימים
              </Button>
              <p className="text-sm text-gray-500 mt-4">
                ללא חיוב בתקופת הניסיון • ביטול בקליק אחד
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}